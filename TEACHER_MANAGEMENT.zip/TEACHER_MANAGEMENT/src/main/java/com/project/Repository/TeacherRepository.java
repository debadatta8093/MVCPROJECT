package com.project.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.project.Domain.Teacher;

public interface TeacherRepository  extends JpaRepository<Teacher,Integer>{

	  @Query("select a from Teacher a where a.mob=:data OR a.name=:data") 
	  public List<Teacher> login(@Param("data") String data);
	 
}
