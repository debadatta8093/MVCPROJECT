package com.project.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.Domain.Dto;
import com.project.Domain.Teacher;
import com.project.Service.Teacherserviceint;

@Controller
public class Teachercontroller {
	@Autowired
	 private Teacherserviceint serv;
	@GetMapping("/")
	public String first()  {
		
	return "teacherinsert";	
	}
	  
   @PostMapping("/insert")
   public  String insertPage(@ModelAttribute Teacher te,Model m)  {
	         String msg=serv.insertData(te);
	         m.addAttribute("msg", msg);
	   return"teacherinsert";
	   
   }
   
   @GetMapping("/teacherlogin")
   public void teacherlogin()
   {
	   
   }
   
   @PostMapping("/checkLogin")
   public String checkLogin(@RequestParam("mob")String mob,Model m)
   {
	   List<Dto> loginPage = serv.loginPage(mob);
	   m.addAttribute("data", loginPage);
	   return "logindata";
   }
   
   @GetMapping("/show")
   public String showallData(Model m) {
	   
	    List<Teacher> lt = serv.showData();
	   m.addAttribute("teacher",lt);
	   return"Alldata";
   }
   
   
   @GetMapping("/teacherupdate")
   public String  updateTeacherform(@RequestParam("uid") Integer id ,Model m) {
	 Teacher ti =serv.getId(id);
	 m.addAttribute("teacher", ti);
	   return"teacherupdate";
   }
   
   @PostMapping("/update")
   public String  updateTeacherdata(Teacher teacher) {
	 serv.updateData(teacher); 
	   return"redirect:show";
	   
   }
   @GetMapping("/teacherdelete")
   public String  deleteData(@RequestParam("did") Integer id ) {

	 serv.deleteData(id); 
	   return"redirect:show";
	   
   }
}
