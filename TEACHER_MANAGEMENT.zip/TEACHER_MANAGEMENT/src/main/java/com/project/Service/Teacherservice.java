package com.project.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.Domain.Dto;
import com.project.Domain.Teacher;
import com.project.Repository.TeacherRepository;

@Service
public class Teacherservice  implements Teacherserviceint{
	
	@Autowired
	 private TeacherRepository  repo;
	
	@Override 
	public String insertData(Teacher te)  {
	Teacher st=repo.save(te);
	if(st!=null)
	{
		return"Record Inserted";
	}
	else
	{
		return "record inserted unsuccessful";
	}

  }
	
	@Override
	public List<Dto> loginPage(String mob)
	{
		List<Teacher> allTeacher = repo.login(mob);
		
		List<Dto> lst=new ArrayList<>();
		
		for(Teacher teacher:allTeacher)
		{
			String cls=teacher.getClasses();
			String sub=teacher.getSubject();
			
			Dto dt=new Dto();
			dt.setCls(cls);
			dt.setSub(sub);
			
			lst.add(dt);
		}
		
		return lst;
	}	
	
	@Override
	public List<Teacher> showData() {
	 	List<Teacher> lt =repo.findAll();
	 	return lt;
	}
	
	@Override
	public Teacher getId(Integer id) {
		Teacher te=repo.findById(id).get();
		return te;
	}
	
	@Override
	public Teacher updateData(Teacher te) {
	Teacher ut=	repo.save(te);
	return ut;
	}
	
	@Override
    public void deleteData(Integer id)   {
    	repo.deleteById(id);
    }

}
