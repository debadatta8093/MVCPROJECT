package com.project.Service;

import java.util.List;

import com.project.Domain.Dto;
import com.project.Domain.Teacher;

public interface Teacherserviceint {
	public String insertData(Teacher te);
	public List<Dto> loginPage(String mob);
	public List<Teacher> showData();
	public Teacher updateData(Teacher te);  
    public Teacher getId(Integer id);
    public void deleteData(Integer id);
}
